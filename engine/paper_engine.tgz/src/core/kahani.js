// Kahani 2D kit: cinematic cut-out storytelling (night palettes, glow, fog, motes, parallax, puppet characters).
// Everything draws with the shared ctx from lib.js. Pure functions of their arguments (time is passed in).
import { ctx, setCtx, W, H, clamp, lerp, rnd, TAU } from './lib.js';

export const K = {
  ink: '#1E130C', night0: '#060A18', night1: '#0E1A36', night2: '#22335A', moon: '#F4F1E4', warm: '#FFB45A', gold: '#F2C46B',
  skin: '#C98B5E', skinD: '#9C6440', skinL: '#E0A675', cloth: '#E8DFC9', clothD: '#B9AE96', red: '#B32A2E', orange: '#E07A2C',
  steel: '#8C95A3', steelD: '#4C5563', log: '#7A5434', logD: '#4E3420', logL: '#A57A4E', ring: '#E2B77A', cyan: '#6FE3F5',
};

// ───────── layers (offscreen canvases so a character can be lit as one piece) ─────────
const POOL = {};
export function layer(name) {
  if (!POOL[name]) { const c = document.createElement('canvas'); c.width = W; c.height = H; POOL[name] = { c, g: c.getContext('2d') }; }
  const L = POOL[name]; L.g.setTransform(1, 0, 0, 1, 0, 0); L.g.globalAlpha = 1; L.g.globalCompositeOperation = 'source-over'; L.g.clearRect(0, 0, W, H); return L;
}
/** draw fn() into a layer, optionally light it (lights = [[gradientFn, alpha, mode]]), then composite it */
export function lit(name, fn, lights = [], alpha = 1) {
  const main = ctx, L = layer(name); setCtx(L.g); fn();
  for (const [grad, a, mode] of lights) { L.g.globalCompositeOperation = mode || 'source-atop'; L.g.globalAlpha = a; L.g.fillStyle = grad(L.g); L.g.fillRect(0, 0, W, H); }
  L.g.globalCompositeOperation = 'source-over'; L.g.globalAlpha = 1; setCtx(main);
  ctx.save(); ctx.globalAlpha = alpha; ctx.drawImage(L.c, 0, 0); ctx.restore();
}
export const linGrad = (x0, y0, x1, y1, stops) => (g) => { const gr = g.createLinearGradient(x0, y0, x1, y1); stops.forEach(([o, c]) => gr.addColorStop(o, c)); return gr; };
export const radGrad = (x, y, r, stops) => (g) => { const gr = g.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([o, c]) => gr.addColorStop(o, c)); return gr; };

// ───────── atmosphere ─────────
export function sky(stops) { const g = ctx.createLinearGradient(0, 0, 0, H); stops.forEach(([o, c]) => g.addColorStop(o, c)); ctx.fillStyle = g; ctx.fillRect(-200, -200, W + 400, H + 400); }
export function glow(x, y, r, color, a = 1) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = a; const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, color); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); ctx.restore();
}
export function stars(t, n = 90, seed = 1, yMax = 1000, a = 1) {
  ctx.save(); for (let i = 0; i < n; i++) { const x = rnd(seed + i) * W, y = rnd(seed + i * 3.1) * yMax, tw = 0.5 + 0.5 * Math.sin(t * (1 + rnd(i) * 2) + i);
    ctx.globalAlpha = a * (0.25 + 0.6 * tw) * (1 - y / yMax * 0.6); ctx.fillStyle = '#FFF6E0'; ctx.beginPath(); ctx.arc(x, y, 1.2 + rnd(i + 9) * 2, 0, TAU); ctx.fill(); } ctx.restore();
}
export function moon(x, y, r, a = 1) {
  glow(x, y, r * 7, 'rgba(150,180,255,0.35)', a); glow(x, y, r * 2.6, 'rgba(235,240,255,0.55)', a);
  ctx.save(); ctx.globalAlpha = a; const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r); g.addColorStop(0, '#FFFFFF'); g.addColorStop(1, '#D9DEEA');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.globalAlpha = a * 0.12; ctx.fillStyle = '#7A8399';
  for (const [dx, dy, rr] of [[-0.3, -0.1, 0.22], [0.25, 0.2, 0.16], [0.1, -0.4, 0.1]]) { ctx.beginPath(); ctx.arc(x + dx * r, y + dy * r, rr * r, 0, TAU); ctx.fill(); } ctx.restore();
}
/** drifting fog bank: soft stretched blobs around y, height h */
export function fog(t, y, h, a = 0.35, color = '200,215,240', speed = 20, seed = 3, n = 7) {
  ctx.save(); for (let i = 0; i < n; i++) {
    const w = 500 + rnd(seed + i) * 700, x = ((rnd(seed + i * 7) * (W + w) + t * speed * (0.6 + rnd(i) * 0.8)) % (W + w * 2)) - w, yy = y + (rnd(seed + i * 5) - 0.5) * h;
    ctx.save(); ctx.translate(x, yy); ctx.scale(1, 0.28 + rnd(i + 2) * 0.2); const g = ctx.createRadialGradient(0, 0, 0, 0, 0, w / 2);
    g.addColorStop(0, `rgba(${color},${a})`); g.addColorStop(1, `rgba(${color},0)`); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, TAU); ctx.fill(); ctx.restore();
  } ctx.restore();
}
/** floating dust motes / embers in a box */
export function motes(t, n = 40, seed = 5, color = '255,220,160', box = [0, 0, W, H], a = 0.8, rise = 18) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < n; i++) { const [x0, y0, w, h] = box; const x = x0 + ((rnd(seed + i) * w + Math.sin(t * 0.6 + i) * 20 + t * 6 * (rnd(i + 4) - 0.5) * 4) % w + w) % w;
    const y = y0 + ((rnd(seed + i * 3) * h - t * rise * (0.5 + rnd(i + 1))) % h + h) % h, r = 1.5 + rnd(seed + i * 11) * 4, tw = 0.4 + 0.6 * Math.abs(Math.sin(t * 1.3 + i));
    const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3); g.addColorStop(0, `rgba(${color},${a * tw})`); g.addColorStop(1, `rgba(${color},0)`); ctx.fillStyle = g; ctx.fillRect(x - r * 3, y - r * 3, r * 6, r * 6); }
  ctx.restore();
}
/** silhouette hill band: baseline y, amplitude, scroll offset (parallax) */
export function hills(y, amp, color, seed = 1, off = 0, wave = 380) {
  ctx.beginPath(); ctx.moveTo(-50, H + 50); for (let x = -50; x <= W + 50; x += 20) { const u = (x + off) / wave; ctx.lineTo(x, y - amp * (0.55 + 0.3 * Math.sin(u + seed) + 0.15 * Math.sin(u * 2.7 + seed * 3))); }
  ctx.lineTo(W + 50, H + 50); ctx.closePath(); ctx.fillStyle = color; ctx.fill();
}
/** silhouette tree line (rounded canopies) with parallax offset */
export function trees(y, size, color, seed = 2, off = 0, gap = 150) {
  ctx.fillStyle = color; const start = Math.floor(off / gap) - 1;
  for (let k = start; k < start + W / gap + 3; k++) { const x = k * gap - off + rnd(k * 1.7 + seed) * gap * 0.6, s = size * (0.6 + rnd(k + seed * 5) * 0.7);
    ctx.fillRect(x - s * 0.06, y - s * 0.9, s * 0.12, s * 0.9); ctx.beginPath(); ctx.ellipse(x, y - s * 1.05, s * 0.42, s * 0.5, 0, 0, TAU); ctx.ellipse(x + s * 0.25, y - s * 0.8, s * 0.3, s * 0.32, 0, 0, TAU); ctx.ellipse(x - s * 0.25, y - s * 0.78, s * 0.28, s * 0.3, 0, 0, TAU); ctx.fill(); }
}
/** side-view road band from y0 to y1, dashes scrolling with off (px) */
export function roadSide(y0, y1, off, light = 0.0) {
  const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, '#1A1D26'); g.addColorStop(1, '#2A2E39'); ctx.fillStyle = g; ctx.fillRect(-100, y0, W + 200, y1 - y0);
  ctx.fillStyle = 'rgba(230,220,190,0.55)'; ctx.fillRect(-100, y0 + 6, W + 200, 4); const m = (y0 + y1) / 2;
  ctx.fillStyle = 'rgba(242,194,48,0.75)'; for (let x = -((off % 220) + 220); x < W + 220; x += 220) ctx.fillRect(x, m, 110, 8);
  ctx.fillStyle = '#0B0D12'; ctx.fillRect(-100, y1, W + 200, H - y1 + 100);
  if (light > 0) glow(W / 2, m, 700, `rgba(255,190,110,${0.12 * light})`);
}
export function vignette(a = 0.6) { const g = ctx.createRadialGradient(540, 900, 300, 540, 960, 1250); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${a})`); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }

// ───────── shapes with outline ─────────
function shape(path, fill, lw = 5, stroke = K.ink) { ctx.beginPath(); path(); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (lw) { ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke(); } }
const vg = (y0, y1, a, b) => { const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, a); g.addColorStop(1, b); return g; };

// ───────── LOG TRUCK, side view, facing right. (x, y) = rear end on the ground, s = px per metre ─────────
// o: { roll (m travelled), shift (m logs forward), dip (rad nose-down), brake 0..1, beam 0..1, line (glow colour → line-art mode), guard 0..1 glow, driver bool, logsHot 0..1 }
export function truck(x, y, s, o = {}) {
  const L = o.line, F = (c) => (L ? 'rgba(0,0,0,0)' : c), S = L || K.ink, lw = L ? 4 : Math.max(2, s * 0.045);
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.lineWidth = lw / s;
  if (L) { ctx.shadowColor = L; ctx.shadowBlur = 18; }
  ctx.translate(1.5, 0); ctx.rotate(o.dip || 0); ctx.translate(-1.5, 0);           // pivot near the rear wheels
  const P = (fn, fill) => { ctx.beginPath(); fn(); if (!L) { ctx.fillStyle = fill; ctx.fill(); } ctx.strokeStyle = S; ctx.lineWidth = lw / s; ctx.lineJoin = 'round'; ctx.stroke(); };
  // beam
  if (o.beam && !L) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const g = ctx.createLinearGradient(8.9, 0, 26, 0); g.addColorStop(0, `rgba(255,214,140,${0.55 * o.beam})`); g.addColorStop(1, 'rgba(255,214,140,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(8.95, -1.5); ctx.lineTo(24, -2.9); ctx.lineTo(24, 0.0); ctx.lineTo(8.95, -1.35); ctx.fill(); ctx.restore(); }
  // chassis + bed
  P(() => ctx.rect(-0.1, -1.02, 9.0, 0.32), F('#1D2027'));
  P(() => ctx.rect(-0.15, -1.3, 6.55, 0.28), F('#3A3F49'));
  // logs (3 rows, each two staggered logs), slide with shift
  ctx.save(); ctx.translate(o.shift || 0, 0);
  const rows = o.empty ? [] : [[-1.3, 0.6, 0], [-1.84, 0.56, 0.15], [-2.36, 0.52, -0.1]];
  rows.forEach(([yb, d, dx], ri) => {
    for (let k = 1; k >= 0; k--) {
      const x0 = -0.35 + dx + k * 0.18 + rnd(ri * 3 + k) * 0.15, x1 = 6.05 + dx * 0.5 + k * 0.05 - rnd(ri + k * 4) * 0.12, top = yb - d - k * 0.05, r = d / 2;
      const fill = L ? null : (() => { const g = ctx.createLinearGradient(0, top, 0, top + d); g.addColorStop(0, k ? '#6A4729' : K.logL); g.addColorStop(0.5, k ? '#5A3C22' : K.log); g.addColorStop(1, K.logD); return g; })();
      P(() => { ctx.moveTo(x0, top); ctx.lineTo(x1, top); ctx.ellipse(x1, top + r, r * 0.28, r, 0, -Math.PI / 2, Math.PI / 2); ctx.lineTo(x0, top + d); ctx.closePath(); }, fill);
      if (!L) { ctx.save(); ctx.globalAlpha = 0.28; ctx.strokeStyle = '#2E1D10'; ctx.lineWidth = 0.025; for (let b = 0; b < 9; b++) { const by = top + d * (0.18 + 0.08 * b); const bx = x0 + 0.3 + rnd(ri * 40 + k * 20 + b) * 3.5; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + 0.8 + rnd(b + ri) * 1.6, by + 0.01); ctx.stroke(); } ctx.restore(); }
      // rear end (rings)
      P(() => ctx.ellipse(x0, top + r, r * 0.3, r, 0, 0, TAU), F(K.ring));
      if (!L) { ctx.strokeStyle = 'rgba(140,90,45,0.6)'; ctx.lineWidth = 0.018; for (let q = 0.3; q < 1; q += 0.22) { ctx.beginPath(); ctx.ellipse(x0, top + r, r * 0.3 * q, r * q, 0, 0, TAU); ctx.stroke(); } }
    }
  });
  if (o.logsHot && !L) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = o.logsHot; const g = ctx.createLinearGradient(-0.3, 0, 6.2, 0); g.addColorStop(0, 'rgba(255,60,40,0)'); g.addColorStop(1, 'rgba(255,60,40,0.55)'); ctx.fillStyle = g; ctx.fillRect(-0.4, -2.95, 6.7, 1.7); ctx.restore(); }
  // chains
  for (const cx of (o.empty ? [] : [1.4, 4.3])) { ctx.beginPath(); ctx.moveTo(cx, -1.3); ctx.quadraticCurveTo(cx + 0.12, -2.2, cx, -2.92); ctx.strokeStyle = L || '#15171C'; ctx.lineWidth = 0.07; ctx.stroke(); if (!L) { ctx.strokeStyle = 'rgba(200,210,225,0.35)'; ctx.lineWidth = 0.02; ctx.setLineDash([0.06, 0.06]); ctx.stroke(); ctx.setLineDash([]); } }
  ctx.restore();
  // stakes
  for (const sx of [0.25, 2.6, 4.9]) P(() => ctx.rect(sx, -3.0, 0.12, 1.72), F('#262A31'));
  // cab guard (steel column with rails)
  ctx.save(); if (o.guard && !L) { ctx.shadowColor = K.gold; ctx.shadowBlur = 40 * o.guard; }
  P(() => ctx.rect(6.32, -3.25, 0.2, 1.97), F(vg(-3.25, -1.3, '#B9C2CF', '#5B6472')));
  for (let r = 0; r < 6; r++) P(() => ctx.rect(6.27, -3.2 + r * 0.36, 0.3, 0.07), F('#9AA3B1'));
  ctx.restore();
  // cab
  P(() => { ctx.moveTo(6.6, -1.0); ctx.lineTo(6.6, -3.05); ctx.quadraticCurveTo(6.62, -3.3, 6.9, -3.3); ctx.lineTo(8.4, -3.3); ctx.quadraticCurveTo(8.8, -3.28, 8.86, -2.9); ctx.lineTo(8.95, -1.9); ctx.lineTo(9.0, -1.0); ctx.closePath(); }, F(vg(-3.3, -1, '#F08B3A', '#B9551C')));
  if (!L) { [['#1F7A4C', -1.55, 0.12], ['#F7D046', -1.42, 0.07], ['#C8242F', -1.34, 0.07], ['#2B5BA8', -1.26, 0.07]].forEach(([c, yy, hh]) => { ctx.fillStyle = c; ctx.fillRect(6.62, yy, 2.34, hh); });
    ctx.fillStyle = '#F7D046'; for (let q = 6.7; q < 8.9; q += 0.22) { ctx.beginPath(); ctx.moveTo(q, -1.62); ctx.lineTo(q + 0.08, -1.78); ctx.lineTo(q + 0.16, -1.62); ctx.fill(); } }
  P(() => { ctx.moveTo(7.55, -2.95); ctx.lineTo(8.55, -2.95); ctx.lineTo(8.65, -2.15); ctx.lineTo(7.55, -2.15); ctx.closePath(); }, F(vg(-2.95, -2.15, '#2B3E63', '#101828')));
  if (o.driver !== false && !L) { ctx.fillStyle = '#0A0E16'; ctx.beginPath(); ctx.ellipse(8.0, -2.55, 0.17, 0.2, 0, 0, TAU); ctx.fill(); ctx.fillRect(7.75, -2.38, 0.5, 0.25); }
  if (!L) { ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.beginPath(); ctx.moveTo(7.7, -2.95); ctx.lineTo(7.95, -2.95); ctx.lineTo(7.7, -2.4); ctx.fill(); }
  P(() => ctx.rect(6.75, -2.95, 0.7, 1.55), F('rgba(0,0,0,0.06)'));                                 // door
  P(() => ctx.rect(8.75, -3.45, 0.5, 0.1), F('#1F7A4C'));                                             // visor
  P(() => ctx.rect(8.9, -1.15, 0.3, 0.2), F('#2B2E34'));                                              // bumper
  P(() => ctx.rect(8.92, -1.55, 0.1, 0.22), F('#FFF3C4'));                                            // headlight
  if (o.beam && !L) glowLocal(8.97, -1.44, 0.9, `rgba(255,220,150,${0.9 * o.beam})`);
  // wheels
  for (const wx of [1.0, 2.15, 7.85]) { ctx.save(); ctx.translate(wx, -0.52); ctx.rotate((o.roll || 0) / 0.52);
    P(() => ctx.arc(0, 0, 0.52, 0, TAU), F('#14151A')); P(() => ctx.arc(0, 0, 0.27, 0, TAU), F('#B3262C'));
    if (!L) { ctx.fillStyle = '#E8E1D0'; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(Math.cos(k * 1.2566) * 0.16, Math.sin(k * 1.2566) * 0.16, 0.035, 0, TAU); ctx.fill(); } }
    ctx.restore(); }
  // tail light
  P(() => ctx.rect(-0.18, -0.95, 0.12, 0.16), F(o.brake ? '#FF3030' : '#5A1012'));
  if (o.brake && !L) glowLocal(-0.12, -0.87, 1.4, `rgba(255,40,30,${0.8 * o.brake})`);
  ctx.restore();
}
function glowLocal(x, y, r, c) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, c); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); ctx.restore(); }

// ───────── RAMESH, cut-out driver portrait. (x, y) = base of the neck, s = scale (head ≈ 270 px at s 1) ─────────
// o: { lid 0..1, wide 0..1, gaze [x,y], tilt (rad), mouth 0..1, breathe 0..1, hands: 'wheel'|'down'|'mala', handY }
export function ramesh(x, y, s, o = {}) {
  ctx.save(); ctx.translate(x, y + (o.breathe || 0) * 6); ctx.scale(s, s);
  const lw = 6;
  // torso: kurta + red check gamchha
  shape(() => { ctx.moveTo(-175, 40); ctx.quadraticCurveTo(-60, -5, 0, 0); ctx.quadraticCurveTo(60, -5, 175, 40); ctx.quadraticCurveTo(215, 70, 225, 200); ctx.lineTo(240, 700); ctx.lineTo(-240, 700); ctx.lineTo(-225, 200); ctx.quadraticCurveTo(-215, 70, -175, 40); }, vg(0, 700, K.cloth, K.clothD), lw);
  shape(() => { ctx.moveTo(-30, 0); ctx.lineTo(0, 120); ctx.lineTo(30, 0); }, null, 4);
  ctx.save(); ctx.beginPath(); ctx.moveTo(-190, 50); ctx.quadraticCurveTo(-120, 10, -40, 10); ctx.lineTo(-10, 60); ctx.quadraticCurveTo(-100, 70, -150, 260); ctx.lineTo(-225, 250); ctx.closePath(); ctx.fillStyle = K.red; ctx.fill(); ctx.clip();
  ctx.fillStyle = 'rgba(255,230,200,0.35)'; for (let i = -260; i < 0; i += 34) { ctx.fillRect(i, -20, 9, 320); } for (let j = 0; j < 300; j += 34) ctx.fillRect(-260, j, 280, 9); ctx.restore();
  shape(() => { ctx.moveTo(-190, 50); ctx.quadraticCurveTo(-120, 10, -40, 10); ctx.lineTo(-10, 60); ctx.quadraticCurveTo(-100, 70, -150, 260); ctx.lineTo(-225, 250); ctx.closePath(); }, null, lw);
  // neck
  shape(() => { ctx.moveTo(-45, -70); ctx.lineTo(-48, 15); ctx.quadraticCurveTo(0, 35, 48, 15); ctx.lineTo(45, -70); }, vg(-70, 20, K.skinD, K.skin), lw);
  // head
  ctx.save(); ctx.translate(0, -60); ctx.rotate(o.tilt || 0); ctx.translate(0, -120);
  for (const sx of [-1, 1]) shape(() => ctx.ellipse(sx * 104, -5, 20, 34, 0, 0, TAU), K.skinD, lw);
  const face = () => { ctx.moveTo(0, -150); ctx.bezierCurveTo(80, -150, 108, -90, 106, -20); ctx.bezierCurveTo(104, 60, 75, 115, 0, 128); ctx.bezierCurveTo(-75, 115, -104, 60, -106, -20); ctx.bezierCurveTo(-108, -90, -80, -150, 0, -150); };
  const fg = ctx.createRadialGradient(-30, -40, 20, 0, 0, 160); fg.addColorStop(0, K.skinL); fg.addColorStop(0.6, K.skin); fg.addColorStop(1, K.skinD); shape(face, fg, lw);
  ctx.save(); ctx.beginPath(); face(); ctx.clip(); ctx.fillStyle = 'rgba(60,40,30,0.18)'; ctx.beginPath(); ctx.ellipse(0, 95, 95, 50, 0, 0, TAU); ctx.fill(); ctx.restore();   // stubble
  // hair
  shape(() => { ctx.moveTo(-108, -30); ctx.bezierCurveTo(-118, -130, -60, -175, 5, -170); ctx.bezierCurveTo(80, -168, 120, -120, 108, -30); ctx.quadraticCurveTo(95, -95, 40, -112); ctx.quadraticCurveTo(-10, -95, -40, -118); ctx.quadraticCurveTo(-90, -100, -108, -30); }, vg(-175, -30, '#2A1C14', '#0E0907'), lw);
  // brows
  const bw = (o.wide || 0) * 10;
  for (const sx of [-1, 1]) shape(() => { ctx.moveTo(sx * 18, -55 - bw); ctx.quadraticCurveTo(sx * 45, -72 - bw * 1.4, sx * 75, -58 - bw); }, null, 11, '#120A06');
  // eyes
  const lid = clamp(o.lid || 0), open = (1 - lid) * (1 + (o.wide || 0) * 0.55), [gx, gy] = o.gaze || [0, 0];
  for (const sx of [-1, 1]) {
    const ex = sx * 45, ey = -28;
    if (open > 0.08) {
      ctx.save(); ctx.beginPath(); ctx.moveTo(ex - 26, ey); ctx.quadraticCurveTo(ex, ey - 22 * open, ex + 26, ey); ctx.quadraticCurveTo(ex, ey + 15 * open, ex - 26, ey); ctx.closePath(); ctx.fillStyle = '#F2EBDF'; ctx.fill(); ctx.clip();
      ctx.fillStyle = '#3B2414'; ctx.beginPath(); ctx.arc(ex + gx * 8, ey - 2 + gy * 5, 12, 0, TAU); ctx.fill(); ctx.fillStyle = '#0B0604'; ctx.beginPath(); ctx.arc(ex + gx * 8, ey - 2 + gy * 5, 6 - (o.wide || 0) * 2, 0, TAU); ctx.fill();
      ctx.fillStyle = '#FFF'; ctx.beginPath(); ctx.arc(ex + gx * 8 + 4, ey - 6 + gy * 5, 3.5, 0, TAU); ctx.fill(); ctx.restore();
    }
    shape(() => { ctx.moveTo(ex - 28, ey + 1); ctx.quadraticCurveTo(ex, ey - 24 * Math.max(open, 0.05) - 2, ex + 28, ey + 1); }, null, 6, '#120A06');
    if (open < 0.3) shape(() => { ctx.moveTo(ex - 24, ey + 2); ctx.quadraticCurveTo(ex, ey + 9, ex + 24, ey + 2); }, null, 4, '#120A06');
  }
  // nose, mustache, mouth
  shape(() => { ctx.moveTo(-4, -20); ctx.quadraticCurveTo(-10, 25, -18, 38); ctx.quadraticCurveTo(0, 48, 18, 38); }, null, 4.5, '#5A3420');
  shape(() => { ctx.moveTo(-62, 70); ctx.quadraticCurveTo(-40, 48, 0, 56); ctx.quadraticCurveTo(40, 48, 62, 70); ctx.quadraticCurveTo(30, 66, 0, 70); ctx.quadraticCurveTo(-30, 66, -62, 70); }, '#140C08', 3, '#140C08');
  if ((o.mouth || 0) > 0.05) shape(() => ctx.ellipse(0, 88, 20, 10 * o.mouth + 3, 0, 0, TAU), '#3A1612', 4);
  else shape(() => { ctx.moveTo(-22, 88); ctx.quadraticCurveTo(0, 93, 22, 88); }, null, 4.5, '#5A2A20');
  ctx.restore();
  // arms
  const hands = o.hands || 'wheel', hy = o.handY || 0;
  for (const sx of [-1, 1]) {
    if (hands === 'down') continue;
    const tx = hands === 'mala' && sx > 0 ? 40 : sx * 150, ty = hands === 'mala' && sx > 0 ? 260 + hy : 470 + hy;
    shape(() => { ctx.moveTo(sx * 190, 120); ctx.quadraticCurveTo(sx * 250, 380, tx + sx * 30, ty + 40); ctx.lineTo(tx - sx * 40, ty + 10); ctx.quadraticCurveTo(sx * 150, 330, sx * 140, 140); }, vg(100, ty, K.cloth, K.clothD), lw);
    shape(() => ctx.ellipse(tx, ty, 46, 38, sx * 0.4, 0, TAU), vg(ty - 40, ty + 40, K.skin, K.skinD), lw);
  }
  ctx.restore();
}

/** hanging prayer beads (mala) with a small pendant, swinging angle a (rad), from (x, y) length len */
export function mala(x, y, len, a, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(a);
  ctx.strokeStyle = '#3A2414'; ctx.lineWidth = 3 * s; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, len); ctx.stroke();
  for (let i = 0; i < 18; i++) { const yy = len * (i / 18); const g = ctx.createRadialGradient(-2 * s, yy - 2 * s, 1, 0, yy, 9 * s); g.addColorStop(0, '#E58A4A'); g.addColorStop(1, '#7A2E14'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(Math.sin(i * 0.9) * 3 * s, yy, 8 * s, 0, TAU); ctx.fill(); }
  ctx.fillStyle = K.gold; ctx.beginPath(); ctx.moveTo(0, len + 4 * s); ctx.lineTo(18 * s, len + 34 * s); ctx.lineTo(0, len + 64 * s); ctx.lineTo(-18 * s, len + 34 * s); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#7A5A1A'; ctx.lineWidth = 3 * s; ctx.stroke();
  glowLocal(0, len + 34 * s, 50 * s, 'rgba(255,200,110,0.35)'); ctx.restore();
}

/** full-frame eye close-up. o: { open 0..1, wide 0..1, look [x,y], light 'warm'|'red'|'moon', glints 0..1, flicker } */
export function eyeCU(t, o = {}) {
  const warm = o.light === 'red' ? ['#7A2A22', '#3A0F0C'] : ['#A0623E', '#3E2416'];
  sky([[0, '#1A0E08'], [0.5, warm[0]], [1, warm[1]]]);
  const cx = 540, cy = 930, open = clamp(o.open ?? 1) * (1 + (o.wide || 0) * 0.35), [lx, ly] = o.look || [0, 0];
  glow(cx, cy, 700, o.light === 'red' ? 'rgba(255,60,40,0.25)' : 'rgba(255,180,100,0.25)');
  // brow ridge + brow
  { const sg2 = ctx.createRadialGradient(cx, cy - 60, 200, cx, cy, 760); sg2.addColorStop(0, 'rgba(255,200,150,0.18)'); sg2.addColorStop(1, 'rgba(20,8,4,0.5)'); ctx.fillStyle = sg2; ctx.fillRect(0, 0, W, H);
    const by = cy - 400 - (o.wide || 0) * 50; ctx.save(); ctx.strokeStyle = 'rgba(25,12,6,0.85)'; ctx.lineCap = 'round';
    for (let i = 0; i < 70; i++) { const u = i / 70, x = cx - 460 + u * 920, y = by + 60 * Math.pow(2 * u - 1, 2) - 30 + rnd(i) * 30; ctx.lineWidth = 5 + rnd(i + 3) * 5; ctx.beginPath(); ctx.moveTo(x, y + 20); ctx.lineTo(x + 40 + rnd(i) * 20, y - 10 * (1 - u)); ctx.stroke(); } ctx.restore();
    ctx.strokeStyle = 'rgba(60,30,15,0.5)'; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(cx - 400, cy - 60); ctx.bezierCurveTo(cx - 180, cy - 380 * Math.max(open, 0.6), cx + 180, cy - 380 * Math.max(open, 0.6), cx + 410, cy - 70); ctx.stroke(); }
  ctx.save(); ctx.beginPath(); ctx.moveTo(cx - 420, cy); ctx.bezierCurveTo(cx - 200, cy - 300 * open, cx + 200, cy - 300 * open, cx + 430, cy - 10); ctx.bezierCurveTo(cx + 200, cy + 190 * open, cx - 200, cy + 190 * open, cx - 420, cy); ctx.closePath();
  const wg = ctx.createRadialGradient(cx, cy, 50, cx, cy, 450); wg.addColorStop(0, '#F4EADC'); wg.addColorStop(1, '#C9A88C'); ctx.fillStyle = wg; ctx.fill(); ctx.clip();
  ctx.strokeStyle = 'rgba(190,70,60,0.25)'; ctx.lineWidth = 3; for (let i = 0; i < 10; i++) { ctx.beginPath(); ctx.moveTo(cx + (i < 5 ? -420 : 420), cy + (rnd(i) - 0.5) * 120); ctx.quadraticCurveTo(cx + (i < 5 ? -300 : 300), cy + (rnd(i + 3) - 0.5) * 150, cx + (i < 5 ? -230 : 230), cy + (rnd(i + 6) - 0.5) * 80); ctx.stroke(); }
  const ix = cx + lx * 90, iy = cy + ly * 40, ir = 175, ig = ctx.createRadialGradient(ix, iy, 30, ix, iy, ir); ig.addColorStop(0, '#C7843E'); ig.addColorStop(0.5, '#7A4420'); ig.addColorStop(1, '#2A150A');
  ctx.fillStyle = ig; ctx.beginPath(); ctx.arc(ix, iy, ir, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(30,15,5,0.35)'; ctx.lineWidth = 2; for (let a = 0; a < TAU; a += 0.16) { ctx.beginPath(); ctx.moveTo(ix + Math.cos(a) * 70, iy + Math.sin(a) * 70); ctx.lineTo(ix + Math.cos(a + 0.05) * ir, iy + Math.sin(a + 0.05) * ir); ctx.stroke(); }
  ctx.fillStyle = '#080402'; ctx.beginPath(); ctx.arc(ix, iy, 70 - (o.wide || 0) * 28, 0, TAU); ctx.fill();
  const gl = o.glints ?? 1; ctx.globalAlpha = 0.9 * gl; ctx.fillStyle = '#FFF6DE'; ctx.beginPath(); ctx.arc(ix - 55, iy - 50, 22, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(ix + 30, iy - 60, 10, 0, TAU); ctx.fill(); ctx.globalAlpha = 1;
  if (o.light !== 'moon') { glow(ix - 55, iy - 50, 90, `rgba(255,220,150,${0.5 * gl})`); }
  // upper lid shadow
  const sg = ctx.createLinearGradient(0, cy - 300 * open, 0, cy - 60 * open); sg.addColorStop(0, 'rgba(40,20,10,0.75)'); sg.addColorStop(1, 'rgba(40,20,10,0)'); ctx.fillStyle = sg; ctx.fillRect(0, cy - 320, W, 300);
  ctx.restore();
  // lid line + lashes
  ctx.strokeStyle = '#140A05'; ctx.lineWidth = 16; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(cx - 430, cy + 5); ctx.bezierCurveTo(cx - 200, cy - 305 * open, cx + 200, cy - 305 * open, cx + 440, cy - 10); ctx.stroke();
  ctx.lineWidth = 5; for (let i = 1; i < 16; i++) { const u = i / 16, bx = (1 - u) ** 3 * (cx - 430) + 3 * (1 - u) ** 2 * u * (cx - 200) + 3 * (1 - u) * u * u * (cx + 200) + u ** 3 * (cx + 440), by = (1 - u) ** 3 * (cy + 5) + 3 * (1 - u) ** 2 * u * (cy - 305 * open) + 3 * (1 - u) * u * u * (cy - 305 * open) + u ** 3 * (cy - 10);
    ctx.beginPath(); ctx.moveTo(bx, by); ctx.quadraticCurveTo(bx + (u - 0.5) * 40, by - 40, bx + (u - 0.5) * 70, by - 55 - 10 * Math.sin(u * 3)); ctx.stroke(); }
  ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(20,10,5,0.6)'; ctx.beginPath(); ctx.moveTo(cx - 420, cy + 2); ctx.bezierCurveTo(cx - 200, cy + 195 * open, cx + 200, cy + 195 * open, cx + 430, cy - 8); ctx.stroke();
  if (o.flicker) { ctx.fillStyle = `rgba(255,190,110,${o.flicker})`; ctx.globalCompositeOperation = 'lighter'; ctx.fillRect(0, 0, W, H); ctx.globalCompositeOperation = 'source-over'; }
}

/** POV through the windshield at night: road to a vanishing point, headlight beams in fog, an object (tractor-trolley) at distance dist (m, Infinity = none) */
export function pov(t, o = {}) {
  sky([[0, '#05070F'], [0.45, '#121C33'], [0.62, '#1C2640'], [1, '#05060A']]);
  stars(t, 50, 21, 700, 0.6); moon(820, 330, 34, 0.9);
  hills(840, 120, '#0C1222', 4, t * 4); trees(870, 120, '#080C16', 6, t * 20, 120);
  const vx = 540, vy = 860, spd = o.speed ?? 1;
  ctx.fillStyle = '#16181F'; ctx.beginPath(); ctx.moveTo(vx - 18, vy); ctx.lineTo(vx + 18, vy); ctx.lineTo(W + 700, H); ctx.lineTo(-700, H); ctx.closePath(); ctx.fill();
  ctx.fillStyle = 'rgba(242,194,48,0.85)'; const ph = (t * 1.6 * spd) % 1;
  for (let k = 0; k < 9; k++) { const u0 = (k + ph) / 9, u1 = u0 + 0.045, y0 = vy + (H - vy) * u0 ** 2.2, y1 = vy + (H - vy) * Math.min(1, u1) ** 2.2; const w0 = 3 + 22 * u0 ** 2.2, w1 = 3 + 22 * Math.min(1, u1) ** 2.2;
    ctx.beginPath(); ctx.moveTo(vx - w0, y0); ctx.lineTo(vx + w0, y0); ctx.lineTo(vx + w1, y1); ctx.lineTo(vx - w1, y1); ctx.fill(); }
  // beams
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (const sx of [-1, 1]) { const g = ctx.createRadialGradient(vx + sx * 240, H + 100, 50, vx, vy, 1200); g.addColorStop(0, 'rgba(255,215,150,0.38)'); g.addColorStop(1, 'rgba(255,215,150,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(vx + sx * 260, H); ctx.lineTo(vx - 140 + sx * 60, vy + 10); ctx.lineTo(vx + 140 + sx * 60, vy + 10); ctx.closePath(); ctx.fill(); } ctx.restore();
  fog(t, vy - 30, 220, 0.32 * (o.fog ?? 1), '210,215,225', 25, 7, 8); fog(t, vy + 120, 260, 0.24 * (o.fog ?? 1), '255,225,180', -18, 11, 6);
  // the trolley: dark tractor + trolley silhouette, scale ~ 1/dist
  const dist = o.dist ?? Infinity;
  if (dist < 200) { const sc = 900 / dist, by = vy + (H - vy) * Math.pow(Math.min(1, 7 / dist), 1) * 0.55, a = clamp((60 - dist) / 30);
    ctx.save(); ctx.globalAlpha = a; ctx.translate(vx + 40 * (1 - a), by); ctx.scale(sc / 100, sc / 100);
    ctx.fillStyle = '#20232B'; ctx.fillRect(-110, -150, 220, 120); ctx.fillStyle = '#2C3039'; ctx.fillRect(-120, -160, 240, 16);
    ctx.fillStyle = '#14161B'; for (const wx of [-80, 80]) { ctx.beginPath(); ctx.arc(wx, -18, 26, 0, TAU); ctx.fill(); }
    ctx.fillStyle = 'rgba(150,40,30,0.7)'; ctx.fillRect(-100, -60, 22, 10); ctx.fillRect(78, -60, 22, 10);
    ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,220,160,0.18)'; ctx.fillRect(-110, -150, 220, 120); ctx.restore(); }
  // cab foreground: A-pillars, dashboard, wheel, mala
  ctx.fillStyle = '#07080C'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(150, 0); ctx.lineTo(60, 1300); ctx.lineTo(0, 1350); ctx.fill(); ctx.beginPath(); ctx.moveTo(W, 0); ctx.lineTo(W - 150, 0); ctx.lineTo(W - 60, 1300); ctx.lineTo(W, 1350); ctx.fill();
  ctx.fillRect(0, 0, W, 90);
  const dg = ctx.createLinearGradient(0, 1300, 0, H); dg.addColorStop(0, '#15110E'); dg.addColorStop(1, '#050403'); ctx.fillStyle = dg; ctx.beginPath(); ctx.moveTo(0, 1330); ctx.quadraticCurveTo(540, 1260, W, 1330); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
  for (const [gx, c] of [[300, '#7CF29A'], [420, '#FFB45A']]) { glow(gx, 1420, 70, c === '#7CF29A' ? 'rgba(124,242,154,0.35)' : 'rgba(255,180,90,0.35)'); ctx.strokeStyle = c; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(gx, 1420, 34, Math.PI * 0.8, Math.PI * 2.2); ctx.stroke(); }
  ctx.strokeStyle = '#0B0B0D'; ctx.lineWidth = 60; ctx.beginPath(); ctx.ellipse(700, 1900, 430, 330, 0, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke(); ctx.strokeStyle = 'rgba(255,190,120,0.15)'; ctx.lineWidth = 6; ctx.stroke();
  mala(540, 90, 300, Math.sin(t * 2.2) * 0.12 + (o.jolt || 0) * 0.5, 1.1);
}

/** foot slamming the brake pedal, close-up. press 0..1 */
export function pedalCU(t, press) {
  sky([[0, '#0A0605'], [1, '#1C0D0A']]); glow(540, 1150, 800, `rgba(255,40,30,${0.25 + 0.3 * press})`);
  ctx.save(); ctx.translate(560, 1180); ctx.rotate(0.35 * press);
  shape(() => ctx.roundRect(-150, -40, 300, 90, 20), vg(-40, 50, '#6B7280', '#2D3138'), 6); ctx.fillStyle = 'rgba(0,0,0,0.4)'; for (let i = -120; i < 140; i += 40) ctx.fillRect(i, -30, 14, 70);
  shape(() => ctx.rect(-14, 50, 28, 400), '#24272D', 6); ctx.restore();
  const fy = 1180 - 330 + press * 250; ctx.save(); ctx.translate(520, fy); ctx.rotate(-0.15 + press * 0.2);
  shape(() => { ctx.moveTo(-60, -700); ctx.lineTo(60, -700); ctx.lineTo(70, 0); ctx.lineTo(-70, 0); ctx.closePath(); }, vg(-700, 0, '#3A3F4F', '#252A36'), 6);
  shape(() => { ctx.moveTo(-80, -40); ctx.quadraticCurveTo(-90, 90, 0, 140); ctx.lineTo(260, 170); ctx.quadraticCurveTo(320, 160, 300, 100); ctx.quadraticCurveTo(200, 20, 60, -40); ctx.closePath(); }, vg(-40, 170, K.skin, K.skinD), 6);
  shape(() => { ctx.moveTo(-90, 120); ctx.lineTo(320, 150); ctx.lineTo(320, 200); ctx.lineTo(-90, 175); ctx.closePath(); }, '#3B2A1E', 6);
  shape(() => { ctx.moveTo(60, -5); ctx.quadraticCurveTo(150, 60, 230, 150); }, null, 18, '#3B2A1E');
  ctx.restore();
  if (press > 0.5) { ctx.save(); ctx.strokeStyle = `rgba(255,255,255,${0.5 * (press - 0.5) * 2})`; ctx.lineWidth = 8; for (let i = 0; i < 6; i++) { const a = -0.5 + i * 0.2; ctx.beginPath(); ctx.moveTo(560 + Math.cos(a) * 300, 1200 + Math.sin(a) * 300); ctx.lineTo(560 + Math.cos(a) * 420, 1200 + Math.sin(a) * 420); ctx.stroke(); } ctx.restore(); }
}

/** sparks streaming back from (x, y); k 0..1 intensity */
export function sparks(t, x, y, k, n = 26, seed = 9) {
  if (k <= 0) return; ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
  for (let i = 0; i < n; i++) { const life = (t * 2.2 + rnd(seed + i)) % 1, a = Math.PI + 0.35 + rnd(i + seed) * 0.5, sp = 160 + rnd(i * 3) * 260, px = x + Math.cos(a) * sp * life, py = y - Math.sin(a + 0.4) * 90 * life + 160 * life * life;
    ctx.strokeStyle = `rgba(255,${150 + rnd(i) * 90 | 0},60,${k * (1 - life)})`; ctx.lineWidth = 3 + rnd(i + 2) * 3; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + Math.cos(a) * 26, py - Math.sin(a + 0.4) * 10); ctx.stroke(); }
  ctx.restore();
}
/** dust puffs around (x, y), k 0..1 */
export function dust(t, x, y, k, spread = 260, seed = 2) {
  if (k <= 0) return; ctx.save(); for (let i = 0; i < 14; i++) { const r = 60 + rnd(seed + i) * 140, px = x + (rnd(i * 2 + seed) - 0.5) * spread * (0.5 + k), py = y - rnd(i * 3) * spread * 0.4 * k;
    const g = ctx.createRadialGradient(px, py, 0, px, py, r * (0.6 + k)); g.addColorStop(0, `rgba(190,165,130,${0.35 * k})`); g.addColorStop(1, 'rgba(190,165,130,0)'); ctx.fillStyle = g; ctx.fillRect(px - r * 2, py - r * 2, r * 4, r * 4); }
  ctx.restore();
}
/** glowing arrow (diagram) */
export function glowArrow(x0, y0, x1, y1, k, c = K.cyan) {
  if (k <= 0) return; const x = lerp(x0, x1, k), y = lerp(y0, y1, k), a = Math.atan2(y1 - y0, x1 - x0);
  ctx.save(); ctx.shadowColor = c; ctx.shadowBlur = 30; ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 12; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x - Math.cos(a) * 30, y - Math.sin(a) * 30); ctx.stroke(); ctx.translate(x, y); ctx.rotate(a); ctx.beginPath(); ctx.moveTo(20, 0); ctx.lineTo(-40, -32); ctx.lineTo(-40, 32); ctx.closePath(); ctx.fill(); ctx.restore();
}
/** serif label (elegant, for diagrams): text centred at x, y */
export function serifLabel(text, x, y, size, a = 1, color = '#FFFFFF', italic = false) {
  if (a <= 0) return; ctx.save(); ctx.globalAlpha = a; ctx.font = `${italic ? 'italic 700' : '600'} ${size}px Cormorant`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0,0,0,0.8)'; ctx.shadowBlur = 20; ctx.fillStyle = color; ctx.fillText(text, x, y); ctx.restore();
}
/** cab interior seen from behind the driver: back of his head (left), rear window with the guard bars and log ends coming closer (approach 0..1) */
export function rearWindow(t, approach, o = {}) {
  sky([[0, '#0A0C14'], [1, '#05060A']]);
  const wx = 110, wy = 330, ww = 860, wh = 700;
  ctx.save(); ctx.beginPath(); ctx.roundRect(wx, wy, ww, wh, 40); ctx.clip();
  sky([[0, '#16213D'], [1, '#2B3556']]); moon(780, 520, 26, 0.8);
  // log ends (rings) behind the bars, growing as they approach
  const sc = lerp(0.55, 1.45, approach), cxx = wx + ww / 2, cyy = wy + wh * 0.62 + (1 - approach) * 40;
  const ends = [[-1.5, 0.9], [-0.5, 0.9], [0.5, 0.9], [1.5, 0.9], [-1, 0], [0, 0], [1, 0], [-0.5, -0.86], [0.5, -0.86]];
  ends.forEach(([ex, ey], i) => { const r = 62 * sc * (0.92 + rnd(i) * 0.14), x = cxx + ex * 128 * sc, y = cyy + ey * 110 * sc;
    const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, 5, x, y, r); g.addColorStop(0, '#F0CB8E'); g.addColorStop(1, '#B98A52'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#5E3D20'; ctx.lineWidth = 9 * sc; ctx.stroke(); ctx.strokeStyle = 'rgba(140,90,45,0.55)'; ctx.lineWidth = 2.5; for (let q = 0.25; q < 0.95; q += 0.17) { ctx.beginPath(); ctx.arc(x + 2, y, r * q, 0, TAU); ctx.stroke(); } });
  if (o.red) { ctx.fillStyle = `rgba(255,40,30,${0.25 * o.red})`; ctx.fillRect(wx, wy, ww, wh); }
  // guard bars
  const gb = o.guard || 0; ctx.save(); if (gb) { ctx.shadowColor = K.gold; ctx.shadowBlur = 35 * gb; }
  for (let i = 0; i < 8; i++) { const x = wx + 40 + i * 88; ctx.fillStyle = vg(wy, wy + wh, '#C3CBD6', '#59626F'); ctx.fillRect(x, wy, 22, wh); }
  for (const yy of [wy + 60, wy + wh - 80]) { ctx.fillStyle = '#8F98A6'; ctx.fillRect(wx, yy, ww, 26); }
  ctx.restore(); ctx.restore();
  ctx.strokeStyle = '#000'; ctx.lineWidth = 30; ctx.beginPath(); ctx.roundRect(wx, wy, ww, wh, 40); ctx.stroke();
  // driver from behind (head + shoulders, gamchha)
  const hx = 300 + (o.lean || 0) * 30, hy = 1330;
  ctx.fillStyle = '#0E0907'; ctx.beginPath(); ctx.ellipse(hx, hy, 150, 175, 0.05, 0, TAU); ctx.fill();
  ctx.fillStyle = vg(1380, H, '#3A352D', '#141210'); ctx.beginPath(); ctx.moveTo(hx - 330, H); ctx.quadraticCurveTo(hx - 300, 1440, hx - 90, 1400); ctx.lineTo(hx + 90, 1400); ctx.quadraticCurveTo(hx + 320, 1440, hx + 360, H); ctx.fill();
  ctx.fillStyle = '#6E1A1C'; ctx.beginPath(); ctx.moveTo(hx - 250, 1480); ctx.quadraticCurveTo(hx, 1400, hx + 250, 1470); ctx.lineTo(hx + 260, 1530); ctx.quadraticCurveTo(hx, 1460, hx - 260, 1540); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = 'rgba(160,190,255,0.35)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.ellipse(hx, hy, 150, 175, 0.05, -2.6, -0.9); ctx.stroke(); ctx.restore();
}
