// Kahani 2D v3: richer painted environments + living motion (wet-road reflections, passing light sweeps,
// rain on glass, bokeh, rim-lit layered mountains, breathing puppets). Pure functions of time.
import { ctx, W, H, clamp, lerp, rnd, TAU } from './lib.js';
import { K, glow } from './kahani.js';

const vg = (y0, y1, stops) => { const g = ctx.createLinearGradient(0, y0, 0, y1); stops.forEach(([o, c]) => g.addColorStop(o, c)); return g; };

/** painted mountain ridge with a soft rim light on its top edge and subtle texture */
export function ridge(y, amp, colTop, colBot, seed, off, wave, rim = 'rgba(160,190,255,0.35)') {
  const pts = []; for (let x = -60; x <= W + 60; x += 12) { const u = (x + off) / wave; pts.push([x, y - amp * (0.5 + 0.3 * Math.sin(u + seed) + 0.14 * Math.sin(u * 2.3 + seed * 2) + 0.06 * Math.sin(u * 6.1 + seed))]); }
  ctx.beginPath(); ctx.moveTo(-60, H + 60); pts.forEach(([x, yy]) => ctx.lineTo(x, yy)); ctx.lineTo(W + 60, H + 60); ctx.closePath();
  ctx.fillStyle = vg(y - amp, y + 260, [[0, colTop], [1, colBot]]); ctx.fill();
  ctx.save(); ctx.beginPath(); pts.forEach(([x, yy], i) => (i ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy))); ctx.strokeStyle = rim; ctx.lineWidth = 4; ctx.shadowColor = rim; ctx.shadowBlur = 18; ctx.stroke(); ctx.restore();
  // painterly texture strokes
  ctx.save(); ctx.globalAlpha = 0.06; ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 2;
  for (let i = 0; i < 40; i++) { const x = ((rnd(seed * 31 + i) * (W + 200) - off * 0.2) % (W + 200) + W + 200) % (W + 200) - 100, yy = y - amp * 0.3 + rnd(i + seed) * 220; ctx.beginPath(); ctx.moveTo(x, yy); ctx.lineTo(x + 40 + rnd(i) * 60, yy - 10); ctx.stroke(); }
  ctx.restore();
}
/** soft bokeh discs */
export function bokeh(t, n, seed, box, colors, a = 0.5) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < n; i++) { const [x0, y0, w, h] = box, x = x0 + rnd(seed + i) * w + Math.sin(t * 0.3 + i) * 12, y = y0 + rnd(seed + i * 3) * h + Math.cos(t * 0.25 + i) * 8, r = 14 + rnd(i * 7 + seed) * 40;
    const c = colors[i % colors.length], tw = 0.6 + 0.4 * Math.sin(t * 1.2 + i * 2);
    const g = ctx.createRadialGradient(x, y, r * 0.2, x, y, r); g.addColorStop(0, `rgba(${c},${a * tw})`); g.addColorStop(0.75, `rgba(${c},${a * 0.6 * tw})`); g.addColorStop(1, `rgba(${c},0)`); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }
  ctx.restore();
}
/** wet road surface from y0 down: dark glossy with vertical reflection streaks of light sources [[x, color, strength]] */
export function wetRoad(t, y0, lights, off = 0) {
  ctx.fillStyle = vg(y0, H, [[0, '#0E121C'], [0.5, '#090B12'], [1, '#040507']]); ctx.fillRect(-100, y0, W + 200, H - y0 + 100);
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (const [x, c, s] of lights) {
    for (let k = 0; k < 6; k++) { const yy = y0 + 10 + k * 60, wob = Math.sin(t * 3 + k * 1.7 + x) * 6, w = 18 + k * 10, a = s * 0.5 * (1 - k / 7);
      const g = ctx.createLinearGradient(0, yy, 0, yy + 60); g.addColorStop(0, `rgba(${c},${a})`); g.addColorStop(1, `rgba(${c},${a * 0.3})`); ctx.fillStyle = g; ctx.fillRect(x - w / 2 + wob, yy, w, 52); }
  }
  ctx.restore();
  // lane dashes with sheen
  ctx.fillStyle = 'rgba(242,194,48,0.55)'; for (let x = -((off % 260) + 260); x < W + 260; x += 260) ctx.fillRect(x, y0 + 70, 120, 7);
  ctx.save(); ctx.globalAlpha = 0.08; ctx.fillStyle = '#AFC4FF'; for (let i = 0; i < 30; i++) { const x = rnd(i) * W, yy = y0 + 20 + rnd(i + 5) * (H - y0); ctx.fillRect(x, yy, 60 + rnd(i) * 120, 2); } ctx.restore();
}
/** rain streaks (world) */
export function rain(t, n = 120, a = 0.35, seed = 2, slant = 0.25) {
  ctx.save(); ctx.strokeStyle = `rgba(190,210,255,${a})`; ctx.lineWidth = 2;
  for (let i = 0; i < n; i++) { const sp = 1400 + rnd(i + seed) * 900, x = (rnd(i * 3 + seed) * (W + 300) + t * sp * slant) % (W + 300) - 150, y = (rnd(i * 7 + seed) * (H + 200) + t * sp) % (H + 200) - 100, l = 30 + rnd(i) * 40;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - l * slant, y - l); ctx.stroke(); }
  ctx.restore();
}
/** water drops sitting on a windshield (box), each with a highlight, slowly sliding */
export function glassDrops(t, box, n = 40, seed = 5) {
  const [x0, y0, w, h] = box; ctx.save();
  for (let i = 0; i < n; i++) { const r = 4 + rnd(seed + i) * 12, x = x0 + rnd(i * 13 + seed) * w, y = y0 + ((rnd(i * 5 + seed) * h + t * (rnd(i) < 0.2 ? 30 : 2)) % h);
    const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.4, 1, x, y, r); g.addColorStop(0, 'rgba(255,255,255,0.55)'); g.addColorStop(0.4, 'rgba(180,200,240,0.18)'); g.addColorStop(1, 'rgba(20,30,50,0.25)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(x, y, r * 0.8, r, 0, 0, TAU); ctx.fill(); }
  ctx.restore();
}
/** a soft band of light sweeping across the frame (streetlight passing) — returns 0..1 intensity at time t */
export function sweepK(t, period = 1.6, phase = 0) { const p = ((t + phase) % period) / period; return Math.max(0, Math.sin(p * Math.PI)) ** 6; }
export function lightSweep(t, period = 1.6, color = '255,190,110', a = 0.45, phase = 0) {
  const p = ((t + phase) % period) / period, x = lerp(-500, W + 500, p), k = Math.sin(p * Math.PI);
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; const g = ctx.createLinearGradient(x - 380, 0, x + 380, 0);
  g.addColorStop(0, `rgba(${color},0)`); g.addColorStop(0.5, `rgba(${color},${a * k})`); g.addColorStop(1, `rgba(${color},0)`);
  ctx.translate(540, 960); ctx.rotate(-0.25); ctx.translate(-540, -960); ctx.fillStyle = g; ctx.fillRect(-400, -400, W + 800, H + 800); ctx.restore();
}
/** god rays from a point */
export function rays(x, y, n, len, a, color = '200,215,255', t = 0) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < n; i++) { const ang = Math.PI * 0.5 + (i / (n - 1) - 0.5) * 1.1 + Math.sin(t * 0.3 + i) * 0.02, w = 0.03 + rnd(i) * 0.04;
    const g = ctx.createRadialGradient(x, y, 0, x, y, len); g.addColorStop(0, `rgba(${color},${a})`); g.addColorStop(1, `rgba(${color},0)`); ctx.fillStyle = g;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(ang - w) * len, y + Math.sin(ang - w) * len); ctx.lineTo(x + Math.cos(ang + w) * len, y + Math.sin(ang + w) * len); ctx.closePath(); ctx.fill(); }
  ctx.restore();
}
/** decorated truck cabin interior frame (windshield opening, dashboard, garland, stickers) drawn over a scene */
export function cabFrame(t, o = {}) {
  const bump = Math.sin(t * 7) * 2 + Math.sin(t * 2.3) * 3;
  ctx.save(); ctx.translate(0, bump);
  // pillars + roof with tassels
  ctx.fillStyle = '#0B0806'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(W, 0); ctx.lineTo(W, 300); ctx.quadraticCurveTo(540, 240, 0, 300); ctx.fill();
  ctx.fillRect(0, 0, 90, H); ctx.fillRect(W - 90, 0, 90, H);
  const cols = ['#E2463A', '#F2C46B', '#2FBF71', '#3B82F6', '#E07A2C'];
  for (let i = 0; i < 22; i++) { const x = 70 + i * 44, sw = Math.sin(t * 2.2 + i * 0.5) * 4; ctx.strokeStyle = '#3A2A1A'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, 262); ctx.lineTo(x + sw, 300); ctx.stroke();
    ctx.fillStyle = cols[i % 5]; ctx.beginPath(); ctx.moveTo(x + sw - 9, 300); ctx.lineTo(x + sw + 9, 300); ctx.lineTo(x + sw, 330); ctx.fill(); }
  // marigold garland arc
  for (let i = 0; i < 30; i++) { const u = i / 29, x = lerp(110, 970, u), y = 300 + Math.sin(u * Math.PI) * 60 + Math.sin(t * 2 + i) * 1.5; const g = ctx.createRadialGradient(x - 3, y - 3, 1, x, y, 13); g.addColorStop(0, '#FFC64A'); g.addColorStop(1, '#D9661C'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 13, 0, TAU); ctx.fill(); }
  // dashboard
  ctx.fillStyle = vg(1380, H, [[0, '#2A1A10'], [1, '#0C0806']]); ctx.beginPath(); ctx.moveTo(0, 1420); ctx.quadraticCurveTo(540, 1330, W, 1420); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
  ctx.strokeStyle = 'rgba(255,190,110,0.35)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(0, 1420); ctx.quadraticCurveTo(540, 1330, W, 1420); ctx.stroke();
  for (const [gx, c] of [[250, '124,242,154'], [360, '255,180,90'], [470, '255,90,80']]) { glow(gx, 1500, 60, `rgba(${c},0.5)`); ctx.strokeStyle = `rgb(${c})`; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(gx, 1500, 30, Math.PI * 0.8, Math.PI * 2.2); ctx.stroke(); }
  ctx.restore();
}
