// Punch kit (editing upgrade 13 Nov): kinetic hook text, flash hits, rupee counter/meter, gear stick, escape ramp,
// money notes, phone. All draw with the shared ctx; pure functions of their arguments.
import { ctx, W, H, clamp, lerp, eo, eob, rnd, TAU } from './lib.js';
import { K, glow } from './kahani.js';

/** big kinetic text: pops in with an overshoot at time t0 (k = seg progress 0..1), stroked, optional colour + tilt */
export function punchText(text, x, y, size, k, o = {}) {
  if (k <= 0) return;
  const s = lerp(1.6, 1, eob(clamp(k))), a = clamp(k * 3) * (o.alpha ?? 1);
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); ctx.scale(s, s); ctx.globalAlpha = a;
  ctx.font = `900 ${size}px Inter`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  ctx.shadowColor = o.glow || 'rgba(0,0,0,0.6)'; ctx.shadowBlur = o.glow ? 40 : 18;
  ctx.lineWidth = size * 0.16; ctx.strokeStyle = o.stroke || '#120A06'; ctx.strokeText(text, 0, 0);
  ctx.shadowBlur = 0; ctx.fillStyle = o.fill || '#FFFFFF'; ctx.fillText(text, 0, 0); ctx.restore();
}
/** full-frame white/red flash that decays from t0 */
export function flash(t, t0, color = '255,245,220', strength = 0.8, decay = 6) {
  if (t < t0) return; const a = strength * Math.exp(-(t - t0) * decay); if (a < 0.01) return;
  ctx.save(); ctx.fillStyle = `rgba(${color},${a})`; ctx.fillRect(0, 0, W, H); ctx.restore();
}
/** camera shake transform (call inside save/restore) */
export const shake = (k, t) => { if (k > 0) ctx.translate(Math.sin(t * 71) * 16 * k, Math.sin(t * 53 + 2) * 12 * k); };

/** rupee amount formatted Indian style */
export const inr = (n) => { const s = Math.round(Math.abs(n)).toString(); const last3 = s.slice(-3), rest = s.slice(0, -3);
  return (n < 0 ? '−' : '') + '₹' + (rest ? rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' : '') + last3; };

/** glowing digital meter panel with a big number */
export function meter(x, y, w, h, label, value, o = {}) {
  ctx.save(); ctx.globalAlpha = o.alpha ?? 1;
  ctx.fillStyle = 'rgba(8,10,18,0.82)'; ctx.strokeStyle = o.color || K.gold; ctx.lineWidth = 6; ctx.shadowColor = o.color || K.gold; ctx.shadowBlur = 30;
  ctx.beginPath(); ctx.roundRect(x - w / 2, y - h / 2, w, h, 28); ctx.fill(); ctx.stroke(); ctx.shadowBlur = 0;
  ctx.font = '600 34px Montserrat'; ctx.letterSpacing = '6px'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(247,242,232,0.8)'; ctx.fillText(label, x, y - h / 2 + 52); ctx.letterSpacing = '0px';
  ctx.font = `900 ${o.size || 130}px Inter`; ctx.textBaseline = 'middle'; ctx.fillStyle = o.color || K.gold; ctx.shadowColor = o.color || K.gold; ctx.shadowBlur = 24; ctx.fillText(value, x, y + 30); ctx.restore();
}
/** a cost row sliding in: label left, amount right */
export function costRow(x, y, w, label, amount, k, color = '#FF6B5A') {
  if (k <= 0) return; const dx = lerp(-W, 0, eo(clamp(k)));
  ctx.save(); ctx.translate(dx, 0); ctx.globalAlpha = clamp(k * 2);
  ctx.fillStyle = 'rgba(10,12,22,0.78)'; ctx.beginPath(); ctx.roundRect(x, y - 52, w, 104, 22); ctx.fill();
  ctx.fillStyle = color; ctx.fillRect(x, y - 52, 12, 104);
  ctx.font = '600 50px Montserrat'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#F7F2E8'; ctx.fillText(label, x + 40, y + 2);
  ctx.font = '900 64px Inter'; ctx.textAlign = 'right'; ctx.fillStyle = color; ctx.fillText(amount, x + w - 34, y + 4); ctx.restore();
}
/** flying banknotes from (x, y), k 0..1 intensity, upward drift */
export function notes(t, x, y, k, n = 14, seed = 3, dir = -1) {
  if (k <= 0) return;
  for (let i = 0; i < n; i++) { const life = (t * 0.9 + rnd(seed + i)) % 1, px = x + (rnd(i * 7 + seed) - 0.5) * 520 * life + Math.sin(t * 3 + i) * 30, py = y + dir * life * 700, r = Math.sin(t * 4 + i) * 0.8;
    ctx.save(); ctx.globalAlpha = k * (1 - life); ctx.translate(px, py); ctx.rotate(r); ctx.scale(1, 0.55 + 0.45 * Math.abs(Math.sin(t * 5 + i)));
    ctx.fillStyle = '#C9A0D8'; ctx.fillRect(-70, -34, 140, 68); ctx.strokeStyle = '#6A4A7A'; ctx.lineWidth = 4; ctx.strokeRect(-70, -34, 140, 68);
    ctx.fillStyle = '#8A6A9A'; ctx.beginPath(); ctx.arc(0, 0, 18, 0, TAU); ctx.fill(); ctx.font = '900 26px Inter'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#F4E9F7'; ctx.fillText('₹', 0, 1); ctx.restore(); }
}
/** gear stick close-up with an H gate; gear = current gear number (float allowed for motion), glow on the knob */
export function gearStick(t, gear, o = {}) {
  const cx = 540, cy = 900; glow(cx, cy, 700, 'rgba(255,170,90,0.18)');
  // gate plate
  ctx.save(); ctx.fillStyle = '#1C1E24'; ctx.strokeStyle = '#0A0B0E'; ctx.lineWidth = 8; ctx.beginPath(); ctx.roundRect(cx - 300, cy - 260, 600, 520, 60); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = 'rgba(200,205,215,0.55)'; ctx.lineWidth = 14; ctx.lineCap = 'round';
  const gx = [cx - 180, cx, cx + 180];
  ctx.beginPath(); ctx.moveTo(gx[0], cy); ctx.lineTo(gx[2], cy); for (const x of gx) { ctx.moveTo(x, cy - 180); ctx.lineTo(x, cy + 180); } ctx.stroke();
  const pos = { 1: [gx[0], cy - 180], 2: [gx[0], cy + 180], 3: [gx[1], cy - 180], 4: [gx[1], cy + 180], 5: [gx[2], cy - 180], 6: [gx[2], cy + 180] };
  ctx.font = '900 58px Inter'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (const [g, [x, y]] of Object.entries(pos)) { const on = Math.round(gear) === +g; ctx.fillStyle = on ? K.gold : 'rgba(230,230,235,0.45)'; ctx.fillText(g, x, y + (y < cy ? -70 : 70)); }
  // interpolate knob position between gears along the gate (via neutral)
  const g0 = Math.floor(gear), g1 = Math.ceil(gear), f = gear - g0, p0 = pos[g0] || pos[g1], p1 = pos[g1] || pos[g0];
  const via = [lerp(p0[0], p1[0], clamp((f - 0.33) * 3)), f < 0.33 ? lerp(p0[1], cy, f * 3) : f > 0.66 ? lerp(cy, p1[1], (f - 0.66) * 3) : cy];
  const [kx, ky] = f === 0 ? p0 : via;
  ctx.strokeStyle = '#2C2F36'; ctx.lineWidth = 46; ctx.beginPath(); ctx.moveTo(cx, cy + 420); ctx.lineTo(kx, ky); ctx.stroke();
  const kg = ctx.createRadialGradient(kx - 30, ky - 40, 10, kx, ky, 110); kg.addColorStop(0, '#5A5F6B'); kg.addColorStop(1, '#14161B');
  ctx.fillStyle = kg; ctx.beginPath(); ctx.arc(kx, ky, 96, 0, TAU); ctx.fill(); ctx.strokeStyle = '#000'; ctx.lineWidth = 6; ctx.stroke(); ctx.restore();
  glow(kx, ky, 220, `rgba(242,196,107,${0.35 * (o.hot ?? 1)})`);
  // hand
  ctx.save(); ctx.translate(kx, ky - 10); ctx.fillStyle = K.skin; ctx.strokeStyle = K.ink; ctx.lineWidth = 6;
  ctx.beginPath(); ctx.ellipse(0, -40, 120, 80, -0.15, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.fillStyle = K.cloth; ctx.beginPath(); ctx.moveTo(-90, -80); ctx.lineTo(-330, -520); ctx.lineTo(-160, -600); ctx.lineTo(60, -110); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
}
/** side view of a downhill road with an escape ramp branching up-left in gravel; sink 0..1 = truck dug in */
export function escapeRamp(t, o = {}) {
  // ground
  ctx.save();
  ctx.fillStyle = '#0B0D12'; ctx.beginPath(); ctx.moveTo(-100, 1150); ctx.lineTo(W + 100, 1450); ctx.lineTo(W + 100, H); ctx.lineTo(-100, H); ctx.fill();
  // main road (downhill to the right)
  ctx.strokeStyle = '#2A2E39'; ctx.lineWidth = 70; ctx.beginPath(); ctx.moveTo(-100, 1160); ctx.lineTo(W + 100, 1460); ctx.stroke();
  // ramp: branches from x~620 going up-left? we draw it rising to the right on its own lane
  const gx0 = 260, gy0 = 1230, gx1 = 1000, gy1 = 1010;
  const g = ctx.createLinearGradient(0, gy1, 0, gy0 + 120); g.addColorStop(0, '#B9A07A'); g.addColorStop(1, '#7E6748');
  ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(gx0, gy0); ctx.lineTo(gx1, gy1); ctx.lineTo(gx1, gy1 + 130); ctx.lineTo(gx0, gy0 + 130); ctx.closePath(); ctx.fill();
  ctx.fillStyle = 'rgba(60,45,30,0.55)'; for (let i = 0; i < 260; i++) { const u = rnd(i), v = rnd(i + 99), x = lerp(gx0, gx1, u), y = lerp(gy0, gy1, u) + v * 120; ctx.beginPath(); ctx.arc(x, y, 3 + rnd(i + 7) * 5, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = '#E8D3A8'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(gx0, gy0); ctx.lineTo(gx1, gy1); ctx.stroke();
  // sign
  if ((o.sign ?? 1) > 0) { ctx.globalAlpha = o.sign ?? 1; ctx.fillStyle = '#2B2E34'; ctx.fillRect(170, 860, 14, 330);
    ctx.fillStyle = '#1F7A4C'; ctx.beginPath(); ctx.roundRect(40, 760, 360, 150, 16); ctx.fill(); ctx.strokeStyle = '#F7F2E8'; ctx.lineWidth = 6; ctx.stroke();
    ctx.font = '900 40px Inter'; ctx.textAlign = 'center'; ctx.fillStyle = '#F7F2E8'; ctx.fillText('ESCAPE RAMP', 220, 820); ctx.save(); ctx.translate(220, 868); ctx.rotate(-0.6); ctx.fillStyle = '#F7F2E8'; ctx.beginPath(); ctx.moveTo(-50, 8); ctx.lineTo(20, 8); ctx.lineTo(20, 26); ctx.lineTo(56, 0); ctx.lineTo(20, -26); ctx.lineTo(20, -8); ctx.lineTo(-50, -8); ctx.closePath(); ctx.fill(); ctx.restore(); ctx.globalAlpha = 1; }
  ctx.restore();
  return { gx0, gy0, gx1, gy1, ang: Math.atan2(gy1 - gy0, gx1 - gx0) };
}
/** smartphone ringing (glowing) at (x, y) with caller name */
export function phone(t, x, y, s, name, k = 1) {
  if (k <= 0) return; const r = Math.sin(t * 30) * 0.06 * (Math.sin(t * 3) > 0 ? 1 : 0);
  ctx.save(); ctx.globalAlpha = clamp(k * 2); ctx.translate(x, y); ctx.rotate(r); ctx.scale(s, s);
  glow(0, 0, 360, 'rgba(120,200,255,0.35)');
  ctx.fillStyle = '#0E0F13'; ctx.beginPath(); ctx.roundRect(-150, -290, 300, 580, 40); ctx.fill(); ctx.strokeStyle = '#3A3D45'; ctx.lineWidth = 8; ctx.stroke();
  const sg = ctx.createLinearGradient(0, -260, 0, 260); sg.addColorStop(0, '#2B5BA8'); sg.addColorStop(1, '#0F2246'); ctx.fillStyle = sg; ctx.beginPath(); ctx.roundRect(-132, -262, 264, 524, 26); ctx.fill();
  ctx.fillStyle = '#F7F2E8'; ctx.font = '600 30px Montserrat'; ctx.textAlign = 'center'; ctx.fillText('Incoming call', 0, -170);
  ctx.font = '900 54px Inter'; ctx.fillText(name, 0, -90); ctx.fillStyle = '#F2C46B'; ctx.beginPath(); ctx.arc(0, 10, 62, 0, TAU); ctx.fill(); ctx.fillStyle = '#2A1C14'; ctx.beginPath(); ctx.arc(0, -8, 64, Math.PI, TAU); ctx.fill(); ctx.fillStyle = '#C98B5E'; ctx.beginPath(); ctx.arc(0, 20, 44, 0, TAU); ctx.fill();
  ctx.fillStyle = '#2FBF71'; ctx.beginPath(); ctx.arc(-70, 190, 40, 0, TAU); ctx.fill(); ctx.fillStyle = '#E5484D'; ctx.beginPath(); ctx.arc(70, 190, 40, 0, TAU); ctx.fill();
  ctx.restore();
}
