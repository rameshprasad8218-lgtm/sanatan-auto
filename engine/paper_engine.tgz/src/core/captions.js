// Paper-cut devotional captions: big Hindi (Tiro Devanagari) yellow/white in the middle, small English CAPS white below.
import { ctx, clamp, eo } from './lib.js';
import { T } from './timing.js';
let items = [];
export function buildCaptions(script) { items = script.lines.map((l, i) => ({ line: i, hi: l.hi, en: l.en, words: [{ txt: l.en, hi: false }], s: 0, e: 0 })); return items; }
export const captionList = () => items.map((c) => ({ ...c, s: T.lines[c.line].start, e: T.lines[c.line + 1] ? T.lines[c.line + 1].start : T.dur }));
function wrap(text, font, maxW) { ctx.font = font; const ws = text.split(' '), out = []; let cur = ''; for (const w of ws) { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { out.push(cur); cur = w; } else cur = t; } if (cur) out.push(cur); return out; }
export function drawCaption(t) {
  const L = captionList().find((c) => t >= c.s && t < c.e); if (!L) return;
  const lt = t - L.s, a = eo(clamp(lt / 0.18)), col = L.line % 2 ? '#FFFFFF' : '#FFD84A';
  const hf = '400 104px Tiro', ef = '600 40px Montserrat';
  const hl = wrap(L.hi, hf, 900), el = wrap(L.en, ef, 900);
  const hh = hl.length * 128, eh = el.length * 54, top = 985 - (hh + 30 + eh) / 2;
  ctx.save(); ctx.globalAlpha = a; ctx.translate(0, (1 - a) * 18); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  ctx.font = hf; hl.forEach((s, i) => { const y = top + 64 + i * 128; ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 14; ctx.lineWidth = 12; ctx.strokeStyle = '#2A150A'; ctx.strokeText(s, 540, y); ctx.shadowBlur = 0; ctx.fillStyle = col; ctx.fillText(s, 540, y); });
  ctx.font = ef; ctx.letterSpacing = '3px'; el.forEach((s, i) => { const y = top + hh + 30 + 27 + i * 54; ctx.lineWidth = 8; ctx.strokeStyle = '#2A150A'; ctx.strokeText(s, 540, y); ctx.fillStyle = '#FFFFFF'; ctx.fillText(s, 540, y); });
  ctx.restore();
}
