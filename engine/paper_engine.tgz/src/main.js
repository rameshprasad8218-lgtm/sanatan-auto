// Kahani 2D boot + frame: fonts → script + timing → captions → shots. draw(t) is a pure function of film time t.
// Per frame: shot (with a slow push-in), soft dissolve from the previous shot, film grain, vignette, series tag, captions.
import { W, H, setCtx, ctx, clamp, eo, eio } from './core/lib.js';
import { T, loadTiming } from './core/timing.js';
import { buildCaptions, drawCaption, captionList } from './core/captions.js';
import { buildShots } from './shots.js';

const cv = document.getElementById('cv');
const main = cv.getContext('2d'); setCtx(main);
const OP = (window.OP = { ready: false });
const buf = document.createElement('canvas'); buf.width = W; buf.height = H; const bg = buf.getContext('2d');
let seed = 7; const rand = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const GRAIN = [0, 1, 2, 3].map(() => { const c = document.createElement('canvas'); c.width = 540; c.height = 960; const g = c.getContext('2d'), d = g.createImageData(540, 960);
  for (let i = 0; i < d.data.length; i += 4) { const v = 128 + (rand() - 0.5) * 90; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; } g.putImageData(d, 0, 0); return c; });

function shotFrame(i, t, g) {
  const S = OP._shots, sh = S[i], end = i < S.length - 1 ? S[i + 1].at : T.dur, d = end - sh.at, lt = t - sh.at;
  setCtx(g); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const z = 1 + (sh.zoom ?? 0.05) * eio(clamp(lt / d)), [cx, cy] = sh.cam || [540, 960];
  g.save(); g.translate(cx, cy); g.scale(z, z); g.translate(-cx, -cy); sh.draw(lt, d, t); g.restore();
  setCtx(main);
}
function series(t) {
  const s = OP.script, a = clamp((t - 0.6) / 0.8) * 0.92; if (!s.series || a <= 0) return;
  ctx.save(); ctx.globalAlpha = a; ctx.textBaseline = 'alphabetic'; ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = 12;
  ctx.font = '600 30px Montserrat'; ctx.letterSpacing = '7px'; ctx.fillStyle = '#F7F2E8'; ctx.fillText(s.series, 92, 168);
  ctx.fillStyle = '#F2C46B'; ctx.fillRect(92, 192, 46, 3); ctx.font = '600 19px Montserrat'; ctx.letterSpacing = '4px'; ctx.fillStyle = 'rgba(247,242,232,0.75)'; ctx.fillText(s.episode || '', 152, 200);
  ctx.letterSpacing = '0px'; ctx.restore();
}
function draw(t) {
  t = clamp(t, 0, T.dur - 1e-4);
  const S = OP._shots; let i = S.length - 1; while (i > 0 && S[i].at > t) i--;
  shotFrame(i, t, main);
  const lt = t - S[i].at, XF = S[i].xfade ?? 0.3;
  if (i > 0 && lt < XF) { shotFrame(i - 1, t, bg); ctx.save(); ctx.globalAlpha = 1 - eo(lt / XF); ctx.drawImage(buf, 0, 0); ctx.restore(); }
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  const v = ctx.createRadialGradient(540, 900, 380, 540, 960, 1200); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.55)'); ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
  ctx.save(); ctx.globalCompositeOperation = 'overlay'; ctx.globalAlpha = 0.16; ctx.drawImage(GRAIN[Math.floor(t * 24) % 4], 0, 0, W, H); ctx.restore();
  const fade = Math.min(clamp(t / 0.5), clamp((T.dur - t) / 0.6));
  if (fade < 1) { ctx.fillStyle = '#000'; ctx.globalAlpha = 1 - fade; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
  series(t); drawCaption(t);
}

(async () => {
  try {
    await Promise.all(['600 80px Cormorant', 'italic 700 80px Cormorant', '600 30px Montserrat', '900 80px Inter', '400 80px Tiro'].map((f) => document.fonts.load(f)));
    const script = await (await fetch('script.json', { cache: 'no-store' })).json();
    await loadTiming(); buildCaptions(script);
    const { shots, cues } = buildShots(); shots.sort((a, b) => a.at - b.at);
    OP._shots = shots; OP.script = script; OP.duration = () => T.dur; OP.draw = draw;
    OP.frame = (t, q = 0.92) => { draw(t); return cv.toDataURL('image/jpeg', q); };
    OP.shots = () => shots.map((s, i) => ({ id: s.id, at: +s.at.toFixed(3), end: +(i < shots.length - 1 ? shots[i + 1].at : T.dur).toFixed(3), note: s.note || '' }));
    OP.captions = () => captionList().map((c) => ({ s: +c.s.toFixed(3), e: +c.e.toFixed(3), text: c.words.map((w) => (w.hi ? '*' : '') + w.txt).join(' ') }));
    OP.cues = () => cues.slice().sort((a, b) => a.t - b.t);
    OP.ready = true;
    const q = new URLSearchParams(location.search);
    if (!q.has('capture')) {
      if (q.has('t')) draw(+q.get('t'));
      else { const audio = new Audio('data/mix.wav'); let t0 = null; const btn = document.getElementById('play'); btn.hidden = false;
        btn.onclick = () => { btn.hidden = true; t0 = performance.now(); audio.currentTime = 0; audio.play().catch(() => {}); };
        const loop = (now) => { const t = t0 == null ? 0 : (now - t0) / 1000; draw(t); if (t0 != null && t > T.dur) { t0 = null; btn.hidden = false; } requestAnimationFrame(loop); }; requestAnimationFrame(loop); }
    }
  } catch (e) { OP.bootError = String(e && e.stack || e); console.error(e); }
})();
